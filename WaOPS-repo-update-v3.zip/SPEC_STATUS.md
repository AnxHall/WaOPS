# WaOPS Specification Status

Legenda:

- **FROZEN** — decisão base só muda por ADR.
- **APPROVED** — especificação aceita, detalhes podem evoluir.
- **DRAFT** — precisa ser refinada durante desenvolvimento.
- **PENDING** — ainda não consolidado.

| Área | Status |
|---|---|
| Product vision | FROZEN |
| SaaS model | FROZEN |
| Tenant model | FROZEN |
| RBAC model | FROZEN |
| Module/entitlement separation | FROZEN |
| Agent language: Go | FROZEN |
| Agent read-only phase 1 | FROZEN |
| Event-driven module integration | FROZEN |
| Initial storage architecture | APPROVED |
| WaMonitor | APPROVED |
| WaSupport | APPROVED |
| Wantry | APPROVED |
| WaDatabase | APPROVED |
| WaBackup | APPROVED |
| WaKnowledge | APPROVED |
| WaNotify | APPROVED |
| WaRelease | APPROVED |
| WaAI | APPROVED |
| Agent Protocol v1 | DRAFT |
| Metric Catalog v1 | DRAFT |
| Event Catalog v1 | DRAFT |
| Permission Matrix | DRAFT |
| Entitlement Matrix | DRAFT |
| Plugin SDK | PENDING |
| Kubernetes support | PENDING |
| Remote actions/RMM | PENDING |
| Frontend visual specification (`designer.md`) | EXTERNAL AUTHORITY |
