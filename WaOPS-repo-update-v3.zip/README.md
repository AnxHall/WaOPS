# WaOPS — Wasync Operations Platform

WaOPS é uma plataforma SaaS multi-tenant e modular para observabilidade, monitoramento de infraestrutura e aplicações, incidentes, suporte, banco de dados, backup, documentação operacional, releases, notificações e IA.

## Decisões congeladas

- SaaS; sem self-host ou white-label na primeira fase.
- WaAgent próprio em Go.
- Linux e Windows inicialmente.
- Docker coletado quando disponível.
- Agente inicialmente read-only.
- Core sempre ativo.
- Módulos comerciais ativados por entitlement.
- WaSupport, WaDatabase, WaBackup, WaAI e demais módulos são adicionais.
- Subtenants/MSP são capacidade adicional contratável.
- WaAI terá página dedicada e popover lateral.
- BYOK deve permanecer disponível.
- Não haverá status page pública nesta fase.
- `designer.md` é a autoridade visual e UX do frontend.

## Autoridade documental

1. Segurança / isolamento de tenant
2. ADR aceito mais recente
3. Contratos executáveis (`contracts/`)
4. Documento especializado
5. `docs/00-master/WAOPS_MASTER_SPEC.md`
6. `designer.md` para apresentação/UX
7. README
8. issue/comentário informal

`designer.md` nunca pode sobrescrever regras de segurança, RBAC, tenancy, billing, entitlement ou estados de domínio.

## Leitura inicial para agentes

- `AGENTS.md`
- `CONTEXT_HANDOFF.md`
- `SPEC_STATUS.md`
- `docs/00-master/WAOPS_MASTER_SPEC.md`
- `docs/12-engineering/development-rules.md`
- skill específica da tarefa em `skills/`

## Regra para frontend

Antes de qualquer mudança visual:

1. ler `designer.md`;
2. ler `docs/development/frontend/DESIGN_IMPLEMENTATION_RULES.md`;
3. verificar `DESIGN_COMPONENT_MAP.md`;
4. verificar `SCREEN_MAP.md`;
5. implementar todos os estados definidos em `UI_STATE_MATRIX.md`.

## Regra de engenharia

Ferramentas open source pesquisadas são fontes de conhecimento de engenharia.  
Licença e compatibilidade devem ser verificadas antes de reutilização de código ou dependência.
